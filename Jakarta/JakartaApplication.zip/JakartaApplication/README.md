# EmptyJSF
Empty Maven Web JakartaEE (JSF) project
