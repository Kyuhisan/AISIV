package si.um.feri.enums;

public enum carTypeENUM {
    ELECTRIC, GAS, DIESEL, GASOLINE;
}
