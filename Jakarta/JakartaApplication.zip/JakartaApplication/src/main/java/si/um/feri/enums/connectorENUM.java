package si.um.feri.enums;

public enum connectorENUM {
    CHADEMO, CCS, TYPE2, TYPE1, DOMESTIC, TESLA;
}
