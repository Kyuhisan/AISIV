package si.um.feri.enums;

public enum regionENUM {
    EUROPE, ASIA, AMERICA, AFRICA, AUSTRALIA, ANTARCTICA, UNKNOWN
}
