package si.feri.service;

import si.feri.dao.Interfaces.i_dao_Provider;
import si.feri.dao.dao_Provider;
import si.feri.vao.vao_Provider;

import java.util.List;
import java.util.Optional;

public class service_Provider {
    private final i_dao_Provider dao_provider = dao_Provider.getInstance();

    //  create
    public void addProvider(vao_Provider provider) {
        dao_provider.addProvider(provider);
    }

    //  read
    public List<vao_Provider> getProviders() {
        return dao_provider.getProviders();
    }
    public Optional<vao_Provider> getProviderByName(String providerName) {
        return dao_provider.getProviderByName(providerName);
    }

    //  update
    public void updateProvider(vao_Provider updatedProvider) {
        dao_provider.updateProvider(updatedProvider);
    }

    //  delete
    public void deleteProvider(String providerName) {
        dao_provider.deleteProvider(providerName);
    }
}
