package si.feri.enums;

public enum enum_Connector {
    CHADEMO, CCS, TYPE2, TYPE1, DOMESTIC, TESLA;
}
