package si.feri.enums;

public enum enum_CarType {
    ELECTRIC, GAS, DIESEL, GASOLINE;
}
