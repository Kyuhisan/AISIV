package si.feri.enums;

public enum enum_Region {
    EUROPE, ASIA, AMERICA, AFRICA, AUSTRALIA, ANTARCTICA, UNKNOWN
}
